function [time, conductance, event] = getuserdefdata(fullpathname)

%fid = fopen(fullpathname);
%data = textscan(fid, '%f %f','headerlines',0);
%fclose(fid);

%time = data{1};
%conductance = data{2};
%event = {};
